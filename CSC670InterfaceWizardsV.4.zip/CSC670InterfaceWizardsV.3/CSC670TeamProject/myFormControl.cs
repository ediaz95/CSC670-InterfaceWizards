﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSC670TeamProject
{
    
    class myFormControl
    {
       public mainPage eP = new mainPage();
      
      public myFormControl()
        {                            
          eP.Show();
        }
       
    }
}
