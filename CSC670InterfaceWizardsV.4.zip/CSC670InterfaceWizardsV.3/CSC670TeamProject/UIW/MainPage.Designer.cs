﻿namespace CSC670TeamProject
{
    partial class mainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainPage));
            this.lblSoftwareTitle = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.btnCatogories = new System.Windows.Forms.Button();
            this.btnFeaturedItems = new System.Windows.Forms.Button();
            this.btnElectronics = new System.Windows.Forms.Button();
            this.btnAcct = new System.Windows.Forms.Button();
            this.txtBxSearch = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabEndingSoon = new System.Windows.Forms.TabPage();
            this.btnBN4 = new System.Windows.Forms.Button();
            this.btnBN3 = new System.Windows.Forms.Button();
            this.btnBN2 = new System.Windows.Forms.Button();
            this.btnBN1 = new System.Windows.Forms.Button();
            this.btnBid7N = new System.Windows.Forms.Button();
            this.btnBid6N = new System.Windows.Forms.Button();
            this.btnBid5N = new System.Windows.Forms.Button();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.btnBid4N = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabCurrentAuction = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnBid6 = new System.Windows.Forms.Button();
            this.txtBx6 = new System.Windows.Forms.TextBox();
            this.btnBid5 = new System.Windows.Forms.Button();
            this.txtBx5 = new System.Windows.Forms.TextBox();
            this.btnBid4 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtBx4 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnBid3 = new System.Windows.Forms.Button();
            this.txtBx3 = new System.Windows.Forms.TextBox();
            this.btnBid1 = new System.Windows.Forms.Button();
            this.txtBx2 = new System.Windows.Forms.TextBox();
            this.btnBid2 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBx1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tabMainPage = new System.Windows.Forms.TabControl();
            this.btnMagnifer = new System.Windows.Forms.Button();
            this.printToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.picBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.tabEndingSoon.SuspendLayout();
            this.tabCurrentAuction.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabMainPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSoftwareTitle
            // 
            this.lblSoftwareTitle.AutoSize = true;
            this.lblSoftwareTitle.Font = new System.Drawing.Font("Californian FB", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoftwareTitle.Location = new System.Drawing.Point(982, 24);
            this.lblSoftwareTitle.Name = "lblSoftwareTitle";
            this.lblSoftwareTitle.Size = new System.Drawing.Size(24, 14);
            this.lblSoftwareTitle.TabIndex = 0;
            this.lblSoftwareTitle.Text = "I W";
            this.lblSoftwareTitle.Click += new System.EventHandler(this.lblSoftwareTitle_Click);
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Font = new System.Drawing.Font("Georgia", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyName.Location = new System.Drawing.Point(438, 24);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(277, 34);
            this.lblCompanyName.TabIndex = 1;
            this.lblCompanyName.Text = "Property Systems";
            this.lblCompanyName.Click += new System.EventHandler(this.lblCompanyName_Click);
            // 
            // btnCatogories
            // 
            this.btnCatogories.AutoSize = true;
            this.btnCatogories.BackColor = System.Drawing.Color.SkyBlue;
            this.btnCatogories.Location = new System.Drawing.Point(894, 87);
            this.btnCatogories.Name = "btnCatogories";
            this.btnCatogories.Size = new System.Drawing.Size(100, 61);
            this.btnCatogories.TabIndex = 1;
            this.btnCatogories.Text = "All Catogories";
            this.btnCatogories.UseVisualStyleBackColor = false;
            this.btnCatogories.Click += new System.EventHandler(this.btnCatogories_Click);
            // 
            // btnFeaturedItems
            // 
            this.btnFeaturedItems.AutoSize = true;
            this.btnFeaturedItems.BackColor = System.Drawing.Color.SkyBlue;
            this.btnFeaturedItems.Location = new System.Drawing.Point(894, 290);
            this.btnFeaturedItems.Name = "btnFeaturedItems";
            this.btnFeaturedItems.Size = new System.Drawing.Size(100, 61);
            this.btnFeaturedItems.TabIndex = 2;
            this.btnFeaturedItems.Text = "Featured Items";
            this.btnFeaturedItems.UseVisualStyleBackColor = false;
            this.btnFeaturedItems.Click += new System.EventHandler(this.btnFeaturedItems_Click);
            // 
            // btnElectronics
            // 
            this.btnElectronics.BackColor = System.Drawing.Color.SkyBlue;
            this.btnElectronics.Location = new System.Drawing.Point(894, 184);
            this.btnElectronics.Name = "btnElectronics";
            this.btnElectronics.Size = new System.Drawing.Size(100, 61);
            this.btnElectronics.TabIndex = 3;
            this.btnElectronics.Text = "Electronics";
            this.btnElectronics.UseVisualStyleBackColor = false;
            this.btnElectronics.Click += new System.EventHandler(this.btnElectronics_Click);
            // 
            // btnAcct
            // 
            this.btnAcct.BackColor = System.Drawing.Color.SkyBlue;
            this.btnAcct.Location = new System.Drawing.Point(894, 400);
            this.btnAcct.Name = "btnAcct";
            this.btnAcct.Size = new System.Drawing.Size(100, 61);
            this.btnAcct.TabIndex = 4;
            this.btnAcct.Text = "Account ";
            this.btnAcct.UseVisualStyleBackColor = false;
            this.btnAcct.Click += new System.EventHandler(this.btnAcct_Click);
            // 
            // txtBxSearch
            // 
            this.txtBxSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBxSearch.Location = new System.Drawing.Point(80, 60);
            this.txtBxSearch.Name = "txtBxSearch";
            this.txtBxSearch.Size = new System.Drawing.Size(234, 20);
            this.txtBxSearch.TabIndex = 7;
            this.txtBxSearch.TextChanged += new System.EventHandler(this.txtBxListTitle_TextChanged);
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.BackColor = System.Drawing.Color.SkyBlue;
            this.btnExit.Location = new System.Drawing.Point(894, 610);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 53);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(12, 59);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(62, 18);
            this.lblSearch.TabIndex = 11;
            this.lblSearch.Text = "Search ";
            this.lblSearch.Click += new System.EventHandler(this.label33_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(320, 59);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 12;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1,
            this.editToolStripMenuItem,
            this.toolsToolStripMenuItem1,
            this.helpToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(1018, 24);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.BackColor = System.Drawing.Color.LightBlue;
            this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator,
            this.toolStripSeparator1,
            this.printToolStripMenuItem1,
            this.printPreviewToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem1.Text = "File";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(140, 6);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(140, 6);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(140, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator3,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.toolStripSeparator4,
            this.selectAllToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "&Edit";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(141, 6);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(141, 6);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.selectAllToolStripMenuItem.Text = "Select &All";
            // 
            // toolsToolStripMenuItem1
            // 
            this.toolsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.changePasswordToolStripMenuItem});
            this.toolsToolStripMenuItem1.Name = "toolsToolStripMenuItem1";
            this.toolsToolStripMenuItem1.Size = new System.Drawing.Size(48, 20);
            this.toolsToolStripMenuItem1.Text = "&Tools";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accountToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.optionsToolStripMenuItem.Text = "&Options";
            // 
            // accountToolStripMenuItem
            // 
            this.accountToolStripMenuItem.Name = "accountToolStripMenuItem";
            this.accountToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.accountToolStripMenuItem.Text = "Account";
            this.accountToolStripMenuItem.Click += new System.EventHandler(this.accountToolStripMenuItem_Click);
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator5,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem1.Text = "&Help";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(113, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.aboutToolStripMenuItem.Text = "&About...";
            // 
            // tabEndingSoon
            // 
            this.tabEndingSoon.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tabEndingSoon.Controls.Add(this.btnBN4);
            this.tabEndingSoon.Controls.Add(this.btnBN3);
            this.tabEndingSoon.Controls.Add(this.btnBN2);
            this.tabEndingSoon.Controls.Add(this.btnBN1);
            this.tabEndingSoon.Controls.Add(this.btnBid7N);
            this.tabEndingSoon.Controls.Add(this.btnBid6N);
            this.tabEndingSoon.Controls.Add(this.btnBid5N);
            this.tabEndingSoon.Controls.Add(this.textBox22);
            this.tabEndingSoon.Controls.Add(this.textBox21);
            this.tabEndingSoon.Controls.Add(this.textBox20);
            this.tabEndingSoon.Controls.Add(this.textBox19);
            this.tabEndingSoon.Controls.Add(this.btnBid4N);
            this.tabEndingSoon.Controls.Add(this.label25);
            this.tabEndingSoon.Controls.Add(this.label24);
            this.tabEndingSoon.Controls.Add(this.label23);
            this.tabEndingSoon.Controls.Add(this.label22);
            this.tabEndingSoon.Controls.Add(this.pictureBox13);
            this.tabEndingSoon.Controls.Add(this.pictureBox12);
            this.tabEndingSoon.Controls.Add(this.pictureBox11);
            this.tabEndingSoon.Controls.Add(this.pictureBox10);
            this.tabEndingSoon.Location = new System.Drawing.Point(39, 4);
            this.tabEndingSoon.Name = "tabEndingSoon";
            this.tabEndingSoon.Size = new System.Drawing.Size(798, 568);
            this.tabEndingSoon.TabIndex = 2;
            this.tabEndingSoon.Text = "Ending Soon";
            // 
            // btnBN4
            // 
            this.btnBN4.Location = new System.Drawing.Point(650, 403);
            this.btnBN4.Name = "btnBN4";
            this.btnBN4.Size = new System.Drawing.Size(88, 30);
            this.btnBN4.TabIndex = 19;
            this.btnBN4.Text = "Buy Now";
            this.btnBN4.UseVisualStyleBackColor = true;
            this.btnBN4.Click += new System.EventHandler(this.btnBN4_Click);
            // 
            // btnBN3
            // 
            this.btnBN3.Location = new System.Drawing.Point(443, 403);
            this.btnBN3.Name = "btnBN3";
            this.btnBN3.Size = new System.Drawing.Size(93, 30);
            this.btnBN3.TabIndex = 18;
            this.btnBN3.Text = "Buy Now";
            this.btnBN3.UseVisualStyleBackColor = true;
            this.btnBN3.Click += new System.EventHandler(this.btnBN3_Click);
            // 
            // btnBN2
            // 
            this.btnBN2.Location = new System.Drawing.Point(240, 403);
            this.btnBN2.Name = "btnBN2";
            this.btnBN2.Size = new System.Drawing.Size(84, 30);
            this.btnBN2.TabIndex = 17;
            this.btnBN2.Text = "Buy Now";
            this.btnBN2.UseVisualStyleBackColor = true;
            this.btnBN2.Click += new System.EventHandler(this.btnBN2_Click);
            // 
            // btnBN1
            // 
            this.btnBN1.Location = new System.Drawing.Point(52, 403);
            this.btnBN1.Name = "btnBN1";
            this.btnBN1.Size = new System.Drawing.Size(84, 30);
            this.btnBN1.TabIndex = 16;
            this.btnBN1.Text = "Buy Now";
            this.btnBN1.UseVisualStyleBackColor = true;
            this.btnBN1.Click += new System.EventHandler(this.btnBN1_Click);
            // 
            // btnBid7N
            // 
            this.btnBid7N.Location = new System.Drawing.Point(650, 324);
            this.btnBid7N.Name = "btnBid7N";
            this.btnBid7N.Size = new System.Drawing.Size(88, 42);
            this.btnBid7N.TabIndex = 15;
            this.btnBid7N.Text = "Bid Now";
            this.btnBid7N.UseVisualStyleBackColor = true;
            // 
            // btnBid6N
            // 
            this.btnBid6N.Location = new System.Drawing.Point(443, 324);
            this.btnBid6N.Name = "btnBid6N";
            this.btnBid6N.Size = new System.Drawing.Size(88, 42);
            this.btnBid6N.TabIndex = 14;
            this.btnBid6N.Text = "Bid Now";
            this.btnBid6N.UseVisualStyleBackColor = true;
            // 
            // btnBid5N
            // 
            this.btnBid5N.Location = new System.Drawing.Point(231, 324);
            this.btnBid5N.Name = "btnBid5N";
            this.btnBid5N.Size = new System.Drawing.Size(99, 42);
            this.btnBid5N.TabIndex = 13;
            this.btnBid5N.Text = "Bid Now";
            this.btnBid5N.UseVisualStyleBackColor = true;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(635, 269);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(128, 26);
            this.textBox22.TabIndex = 12;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(435, 269);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(108, 26);
            this.textBox21.TabIndex = 11;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(231, 269);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(108, 26);
            this.textBox20.TabIndex = 10;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(43, 269);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(118, 26);
            this.textBox19.TabIndex = 9;
            // 
            // btnBid4N
            // 
            this.btnBid4N.Location = new System.Drawing.Point(52, 322);
            this.btnBid4N.Name = "btnBid4N";
            this.btnBid4N.Size = new System.Drawing.Size(84, 44);
            this.btnBid4N.TabIndex = 8;
            this.btnBid4N.Text = "Bid Now";
            this.btnBid4N.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(658, 26);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(70, 20);
            this.label25.TabIndex = 7;
            this.label25.Text = "Tool Box";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(439, 26);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(84, 20);
            this.label24.TabIndex = 6;
            this.label24.Text = "Silver Ring";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(196, 26);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(186, 20);
            this.label23.TabIndex = 5;
            this.label23.Text = "Remote Controlled Plane";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(39, 26);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(122, 20);
            this.label22.TabIndex = 4;
            this.label22.Text = "Ten Speed Bike";
            // 
            // tabCurrentAuction
            // 
            this.tabCurrentAuction.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tabCurrentAuction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabCurrentAuction.Controls.Add(this.groupBox3);
            this.tabCurrentAuction.Controls.Add(this.groupBox1);
            this.tabCurrentAuction.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCurrentAuction.Location = new System.Drawing.Point(39, 4);
            this.tabCurrentAuction.Name = "tabCurrentAuction";
            this.tabCurrentAuction.Padding = new System.Windows.Forms.Padding(3);
            this.tabCurrentAuction.Size = new System.Drawing.Size(798, 568);
            this.tabCurrentAuction.TabIndex = 1;
            this.tabCurrentAuction.Text = "Current ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnBid6);
            this.groupBox3.Controls.Add(this.txtBx6);
            this.groupBox3.Controls.Add(this.pictureBox6);
            this.groupBox3.Controls.Add(this.btnBid5);
            this.groupBox3.Controls.Add(this.txtBx5);
            this.groupBox3.Controls.Add(this.pictureBox4);
            this.groupBox3.Controls.Add(this.btnBid4);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtBx4);
            this.groupBox3.Controls.Add(this.pictureBox5);
            this.groupBox3.Location = new System.Drawing.Point(15, 266);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(762, 294);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // btnBid6
            // 
            this.btnBid6.Location = new System.Drawing.Point(599, 253);
            this.btnBid6.Name = "btnBid6";
            this.btnBid6.Size = new System.Drawing.Size(75, 23);
            this.btnBid6.TabIndex = 22;
            this.btnBid6.Text = "Bid";
            this.btnBid6.UseVisualStyleBackColor = true;
            this.btnBid6.Click += new System.EventHandler(this.btnBid6_Click);
            // 
            // txtBx6
            // 
            this.txtBx6.Location = new System.Drawing.Point(572, 219);
            this.txtBx6.Multiline = true;
            this.txtBx6.Name = "txtBx6";
            this.txtBx6.Size = new System.Drawing.Size(125, 25);
            this.txtBx6.TabIndex = 21;
            this.txtBx6.TextChanged += new System.EventHandler(this.textBox5_TextChanged_1);
            // 
            // btnBid5
            // 
            this.btnBid5.Location = new System.Drawing.Point(339, 253);
            this.btnBid5.Name = "btnBid5";
            this.btnBid5.Size = new System.Drawing.Size(75, 23);
            this.btnBid5.TabIndex = 19;
            this.btnBid5.Text = "Bid";
            this.btnBid5.UseVisualStyleBackColor = true;
            this.btnBid5.Click += new System.EventHandler(this.btnBid5_Click);
            // 
            // txtBx5
            // 
            this.txtBx5.Location = new System.Drawing.Point(318, 219);
            this.txtBx5.Multiline = true;
            this.txtBx5.Name = "txtBx5";
            this.txtBx5.Size = new System.Drawing.Size(125, 25);
            this.txtBx5.TabIndex = 18;
            this.txtBx5.TextChanged += new System.EventHandler(this.txtBx5_TextChanged);
            // 
            // btnBid4
            // 
            this.btnBid4.Location = new System.Drawing.Point(88, 253);
            this.btnBid4.Name = "btnBid4";
            this.btnBid4.Size = new System.Drawing.Size(75, 23);
            this.btnBid4.TabIndex = 16;
            this.btnBid4.Text = "Bid";
            this.btnBid4.UseVisualStyleBackColor = true;
            this.btnBid4.Click += new System.EventHandler(this.btnBid4_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(569, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 16);
            this.label7.TabIndex = 2;
            this.label7.Text = "Nintendo Game Cube";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(317, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 16);
            this.label8.TabIndex = 3;
            this.label8.Text = "Nintendo DS Lite";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(82, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 16);
            this.label9.TabIndex = 4;
            this.label9.Text = "Gold Watch";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // txtBx4
            // 
            this.txtBx4.Location = new System.Drawing.Point(61, 219);
            this.txtBx4.Multiline = true;
            this.txtBx4.Name = "txtBx4";
            this.txtBx4.Size = new System.Drawing.Size(125, 25);
            this.txtBx4.TabIndex = 1;
            this.txtBx4.TextChanged += new System.EventHandler(this.txtBx4_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.btnBid3);
            this.groupBox1.Controls.Add(this.txtBx3);
            this.groupBox1.Controls.Add(this.pictureBox8);
            this.groupBox1.Controls.Add(this.btnBid1);
            this.groupBox1.Controls.Add(this.txtBx2);
            this.groupBox1.Controls.Add(this.picBox2);
            this.groupBox1.Controls.Add(this.btnBid2);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtBx1);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Location = new System.Drawing.Point(15, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(762, 254);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(585, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 16);
            this.label6.TabIndex = 23;
            this.label6.Text = "Old Currency";
            // 
            // btnBid3
            // 
            this.btnBid3.Location = new System.Drawing.Point(588, 222);
            this.btnBid3.Name = "btnBid3";
            this.btnBid3.Size = new System.Drawing.Size(75, 23);
            this.btnBid3.TabIndex = 21;
            this.btnBid3.Text = "Bid";
            this.btnBid3.UseVisualStyleBackColor = true;
            this.btnBid3.Click += new System.EventHandler(this.btnBid3_Click);
            // 
            // txtBx3
            // 
            this.txtBx3.Location = new System.Drawing.Point(572, 186);
            this.txtBx3.Multiline = true;
            this.txtBx3.Name = "txtBx3";
            this.txtBx3.Size = new System.Drawing.Size(125, 25);
            this.txtBx3.TabIndex = 20;
            this.txtBx3.TextChanged += new System.EventHandler(this.txtBx3_TextChanged);
            // 
            // btnBid1
            // 
            this.btnBid1.Location = new System.Drawing.Point(88, 222);
            this.btnBid1.Name = "btnBid1";
            this.btnBid1.Size = new System.Drawing.Size(75, 23);
            this.btnBid1.TabIndex = 18;
            this.btnBid1.Text = "Bid";
            this.btnBid1.UseVisualStyleBackColor = true;
            this.btnBid1.Click += new System.EventHandler(this.btnBid1_Click);
            // 
            // txtBx2
            // 
            this.txtBx2.Location = new System.Drawing.Point(316, 186);
            this.txtBx2.Multiline = true;
            this.txtBx2.Name = "txtBx2";
            this.txtBx2.Size = new System.Drawing.Size(125, 25);
            this.txtBx2.TabIndex = 17;
            this.txtBx2.TextChanged += new System.EventHandler(this.txtBx2_TextChanged);
            // 
            // btnBid2
            // 
            this.btnBid2.Location = new System.Drawing.Point(339, 225);
            this.btnBid2.Name = "btnBid2";
            this.btnBid2.Size = new System.Drawing.Size(75, 23);
            this.btnBid2.TabIndex = 15;
            this.btnBid2.Text = "Bid";
            this.btnBid2.UseVisualStyleBackColor = true;
            this.btnBid2.Click += new System.EventHandler(this.btnBid2_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(85, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 16);
            this.label12.TabIndex = 7;
            this.label12.Text = "Apple Laptop";
            // 
            // txtBx1
            // 
            this.txtBx1.Location = new System.Drawing.Point(61, 186);
            this.txtBx1.Multiline = true;
            this.txtBx1.Name = "txtBx1";
            this.txtBx1.Size = new System.Drawing.Size(125, 25);
            this.txtBx1.TabIndex = 1;
            this.txtBx1.TextChanged += new System.EventHandler(this.txtBx1_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(313, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(130, 16);
            this.label11.TabIndex = 6;
            this.label11.Text = "Sony Camera A6000";
            // 
            // tabMainPage
            // 
            this.tabMainPage.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabMainPage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabMainPage.Controls.Add(this.tabCurrentAuction);
            this.tabMainPage.Controls.Add(this.tabEndingSoon);
            this.tabMainPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabMainPage.ItemSize = new System.Drawing.Size(125, 35);
            this.tabMainPage.Location = new System.Drawing.Point(31, 87);
            this.tabMainPage.Multiline = true;
            this.tabMainPage.Name = "tabMainPage";
            this.tabMainPage.SelectedIndex = 0;
            this.tabMainPage.Size = new System.Drawing.Size(841, 576);
            this.tabMainPage.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabMainPage.TabIndex = 6;
            // 
            // btnMagnifer
            // 
            this.btnMagnifer.Image = global::CSC670TeamProject.Properties.Resources.magControlPanel20061222;
            this.btnMagnifer.Location = new System.Drawing.Point(878, 516);
            this.btnMagnifer.Name = "btnMagnifer";
            this.btnMagnifer.Size = new System.Drawing.Size(131, 59);
            this.btnMagnifer.TabIndex = 15;
            this.btnMagnifer.UseVisualStyleBackColor = true;
            this.btnMagnifer.Click += new System.EventHandler(this.btnMagnifer_Click);
            // 
            // printToolStripMenuItem1
            // 
            this.printToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripMenuItem1.Image")));
            this.printToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripMenuItem1.Name = "printToolStripMenuItem1";
            this.printToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.printToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.printToolStripMenuItem1.Text = "&Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewToolStripMenuItem.Image")));
            this.printPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.printPreviewToolStripMenuItem.Text = "Print Pre&view";
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripMenuItem.Image")));
            this.cutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.cutToolStripMenuItem.Text = "Cu&t";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripMenuItem.Image")));
            this.copyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.copyToolStripMenuItem.Text = "&Copy";
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripMenuItem.Image")));
            this.pasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.pasteToolStripMenuItem.Text = "&Paste";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(544, 58);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(182, 128);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 20;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(281, 58);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(182, 128);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 17;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.ErrorImage = null;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.InitialImage = null;
            this.pictureBox5.Location = new System.Drawing.Point(33, 58);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(182, 128);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(544, 45);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(182, 128);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 19;
            this.pictureBox8.TabStop = false;
            // 
            // picBox2
            // 
            this.picBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBox2.Image = ((System.Drawing.Image)(resources.GetObject("picBox2.Image")));
            this.picBox2.Location = new System.Drawing.Point(281, 45);
            this.picBox2.Name = "picBox2";
            this.picBox2.Size = new System.Drawing.Size(182, 128);
            this.picBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBox2.TabIndex = 16;
            this.picBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(33, 45);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(182, 128);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(625, 60);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(149, 187);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 3;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(418, 60);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(137, 187);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 2;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(212, 60);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(153, 188);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 1;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(33, 61);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(144, 187);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            // 
            // mainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1018, 686);
            this.ControlBox = false;
            this.Controls.Add(this.btnMagnifer);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txtBxSearch);
            this.Controls.Add(this.tabMainPage);
            this.Controls.Add(this.btnAcct);
            this.Controls.Add(this.btnElectronics);
            this.Controls.Add(this.btnFeaturedItems);
            this.Controls.Add(this.btnCatogories);
            this.Controls.Add(this.lblCompanyName);
            this.Controls.Add(this.lblSoftwareTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(800, 500);
            this.Name = "mainPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home Page";
            this.Load += new System.EventHandler(this.EventPage_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabEndingSoon.ResumeLayout(false);
            this.tabEndingSoon.PerformLayout();
            this.tabCurrentAuction.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabMainPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSoftwareTitle;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.Button btnCatogories;
        private System.Windows.Forms.Button btnFeaturedItems;
        private System.Windows.Forms.Button btnElectronics;
        private System.Windows.Forms.Button btnAcct;
        private System.Windows.Forms.TextBox txtBxSearch;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.TabPage tabEndingSoon;
        private System.Windows.Forms.Button btnBN4;
        private System.Windows.Forms.Button btnBN3;
        private System.Windows.Forms.Button btnBN2;
        private System.Windows.Forms.Button btnBN1;
        private System.Windows.Forms.Button btnBid7N;
        private System.Windows.Forms.Button btnBid6N;
        private System.Windows.Forms.Button btnBid5N;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Button btnBid4N;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.TabPage tabCurrentAuction;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnBid6;
        private System.Windows.Forms.TextBox txtBx6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btnBid5;
        private System.Windows.Forms.TextBox txtBx5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btnBid4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtBx4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnBid3;
        private System.Windows.Forms.TextBox txtBx3;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button btnBid1;
        private System.Windows.Forms.TextBox txtBx2;
        private System.Windows.Forms.PictureBox picBox2;
        private System.Windows.Forms.Button btnBid2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtBx1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TabControl tabMainPage;
        private System.Windows.Forms.ToolStripMenuItem accountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.Button btnMagnifer;
    }
}

