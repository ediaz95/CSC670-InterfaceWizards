﻿namespace CSC670TeamProject
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.lblSoftwareName = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.grpBxLogin = new System.Windows.Forms.GroupBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.userNameTextBox = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.linklblCreate = new System.Windows.Forms.LinkLabel();
            this.linklblDemo = new System.Windows.Forms.LinkLabel();
            this.linklblHelp = new System.Windows.Forms.LinkLabel();
            this.linklblContactUs = new System.Windows.Forms.LinkLabel();
            this.btnExit = new System.Windows.Forms.Button();
            this.pBoxAppLogo = new System.Windows.Forms.PictureBox();
            this.grpBxLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxAppLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSoftwareName
            // 
            this.lblSoftwareName.AutoSize = true;
            this.lblSoftwareName.Font = new System.Drawing.Font("Californian FB", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoftwareName.Location = new System.Drawing.Point(96, 12);
            this.lblSoftwareName.Name = "lblSoftwareName";
            this.lblSoftwareName.Size = new System.Drawing.Size(239, 33);
            this.lblSoftwareName.TabIndex = 1;
            this.lblSoftwareName.Text = "InterFace Wizards";
            this.lblSoftwareName.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(158, 86);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(86, 16);
            this.lblWelcome.TabIndex = 2;
            this.lblWelcome.Text = "Welcome to: ";
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Font = new System.Drawing.Font("Georgia", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyName.Location = new System.Drawing.Point(58, 119);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(277, 34);
            this.lblCompanyName.TabIndex = 3;
            this.lblCompanyName.Text = "Property Systems";
            // 
            // grpBxLogin
            // 
            this.grpBxLogin.Controls.Add(this.btnLogin);
            this.grpBxLogin.Controls.Add(this.passwordTextBox);
            this.grpBxLogin.Controls.Add(this.userNameTextBox);
            this.grpBxLogin.Controls.Add(this.lblPassword);
            this.grpBxLogin.Controls.Add(this.lblUserName);
            this.grpBxLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBxLogin.Location = new System.Drawing.Point(48, 156);
            this.grpBxLogin.Name = "grpBxLogin";
            this.grpBxLogin.Size = new System.Drawing.Size(287, 148);
            this.grpBxLogin.TabIndex = 4;
            this.grpBxLogin.TabStop = false;
            this.grpBxLogin.Text = "Login";
            // 
            // btnLogin
            // 
            this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(212, 123);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(75, 25);
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "Submit";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordTextBox.Location = new System.Drawing.Point(125, 76);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(143, 22);
            this.passwordTextBox.TabIndex = 3;
            this.passwordTextBox.TextChanged += new System.EventHandler(this.passwordTextBox_TextChanged);
            // 
            // userNameTextBox
            // 
            this.userNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameTextBox.Location = new System.Drawing.Point(125, 31);
            this.userNameTextBox.Name = "userNameTextBox";
            this.userNameTextBox.Size = new System.Drawing.Size(143, 22);
            this.userNameTextBox.TabIndex = 2;
            this.userNameTextBox.TextChanged += new System.EventHandler(this.userNameTextBox_TextChanged);
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(26, 76);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(68, 16);
            this.lblPassword.TabIndex = 1;
            this.lblPassword.Text = "Password";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.Location = new System.Drawing.Point(26, 34);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(74, 16);
            this.lblUserName.TabIndex = 0;
            this.lblUserName.Text = "UserName";
            // 
            // linklblCreate
            // 
            this.linklblCreate.AutoSize = true;
            this.linklblCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblCreate.Location = new System.Drawing.Point(124, 329);
            this.linklblCreate.Name = "linklblCreate";
            this.linklblCreate.Size = new System.Drawing.Size(120, 20);
            this.linklblCreate.TabIndex = 5;
            this.linklblCreate.TabStop = true;
            this.linklblCreate.Text = "Create Account";
            this.linklblCreate.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklblCreate_LinkClicked);
            // 
            // linklblDemo
            // 
            this.linklblDemo.AutoSize = true;
            this.linklblDemo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblDemo.Location = new System.Drawing.Point(73, 372);
            this.linklblDemo.Name = "linklblDemo";
            this.linklblDemo.Size = new System.Drawing.Size(211, 20);
            this.linklblDemo.TabIndex = 6;
            this.linklblDemo.TabStop = true;
            this.linklblDemo.Text = "Forgot Password/Username ";
            this.linklblDemo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklblDemo_LinkClicked);
            // 
            // linklblHelp
            // 
            this.linklblHelp.AutoSize = true;
            this.linklblHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblHelp.Location = new System.Drawing.Point(12, 521);
            this.linklblHelp.Name = "linklblHelp";
            this.linklblHelp.Size = new System.Drawing.Size(37, 16);
            this.linklblHelp.TabIndex = 7;
            this.linklblHelp.TabStop = true;
            this.linklblHelp.Text = "Help";
            // 
            // linklblContactUs
            // 
            this.linklblContactUs.AutoSize = true;
            this.linklblContactUs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblContactUs.Location = new System.Drawing.Point(89, 521);
            this.linklblContactUs.Name = "linklblContactUs";
            this.linklblContactUs.Size = new System.Drawing.Size(124, 16);
            this.linklblContactUs.TabIndex = 8;
            this.linklblContactUs.TabStop = true;
            this.linklblContactUs.Text = "Contact Us/Support";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(290, 518);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pBoxAppLogo
            // 
            this.pBoxAppLogo.Image = global::CSC670TeamProject.Properties.Resources.badgenew;
            this.pBoxAppLogo.Location = new System.Drawing.Point(12, 12);
            this.pBoxAppLogo.Name = "pBoxAppLogo";
            this.pBoxAppLogo.Size = new System.Drawing.Size(77, 90);
            this.pBoxAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBoxAppLogo.TabIndex = 0;
            this.pBoxAppLogo.TabStop = false;
            this.pBoxAppLogo.Click += new System.EventHandler(this.pBoxAppLogo_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(377, 555);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.linklblContactUs);
            this.Controls.Add(this.linklblHelp);
            this.Controls.Add(this.linklblDemo);
            this.Controls.Add(this.linklblCreate);
            this.Controls.Add(this.grpBxLogin);
            this.Controls.Add(this.lblCompanyName);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.lblSoftwareName);
            this.Controls.Add(this.pBoxAppLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.grpBxLogin.ResumeLayout(false);
            this.grpBxLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxAppLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pBoxAppLogo;
        private System.Windows.Forms.Label lblSoftwareName;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.GroupBox grpBxLogin;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.TextBox userNameTextBox;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.LinkLabel linklblCreate;
        private System.Windows.Forms.LinkLabel linklblDemo;
        private System.Windows.Forms.LinkLabel linklblHelp;
        private System.Windows.Forms.LinkLabel linklblContactUs;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnExit;
    }
}