﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC670TeamProject
{
    public partial class FeaturedItems : Form
    {
        private int imageNum = -1;
        private int nofImages = 5;

        public FeaturedItems()
        {
            InitializeComponent();
        }
        private void btnHome_Click(object sender, EventArgs e)
        {
        }
       private void btnNext_Click(object sender, EventArgs e)
       {                 
       }
        private void button1_Click(object sender, EventArgs e)
        {
        }
     
                     
    }
}
