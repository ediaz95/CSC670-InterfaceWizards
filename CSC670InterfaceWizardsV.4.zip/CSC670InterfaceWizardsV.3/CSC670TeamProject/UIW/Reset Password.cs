﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC670TeamProject
{
    public partial class Reset_Password : Form
    {
        public Reset_Password()
        {
            InitializeComponent();
        }
        private void lblCompanyName_Click(object sender, EventArgs e)
        {
        }
        private void label22_Click(object sender, EventArgs e)
        {            
        }
        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Reset_Password_Load(object sender, EventArgs e)
        {
        }
    }
}
