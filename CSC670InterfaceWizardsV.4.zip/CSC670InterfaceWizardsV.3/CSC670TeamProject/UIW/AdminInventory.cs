﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC670TeamProject
{
    public partial class adminInventoryPage : Form
    {        
        public adminInventoryPage()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void label1_Click_1(object sender, EventArgs e)
        {
        }
        private void AuctioneerPage_Load(object sender, EventArgs e)
        {
            btnAddItems.Visible = true;       
            btnAddItems.Enabled = true;          
        }
        private void btnMain_Click(object sender, EventArgs e)
        {
        }
        private void btnAuctionItems_Click(object sender, EventArgs e)
        {           
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();            
        }
        private void btnAuctioneers_Click(object sender, EventArgs e)
        {           
        }
        private void btnBidders_Click(object sender, EventArgs e)
        {           
        }
        private void btnMain_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }
        private void btnExit_Click_1(object sender, EventArgs e)
        {
            CSC670TeamProject.adminPage adm = new CSC670TeamProject.adminPage();
            adm.Show();
        }
        private void GroupBox1_Enter(object sender, EventArgs e)
        {
        }
        private void Button2_Click(object sender, EventArgs e)
        {
        }
        private void Label11_Click(object sender, EventArgs e)
        {
        }
        private void RichTextBox2_TextChanged(object sender, EventArgs e)
        {
        }
        private void Button5_Click(object sender, EventArgs e)
        {
        }
        private void Button6_Click(object sender, EventArgs e)
        {
        }
        private void Label4_Click(object sender, EventArgs e)
        {
        }
        private void button9_Click(object sender, EventArgs e)
        {
        }
        private void NumericUpDown1_ValueChanged(object sender, EventArgs e)
        {
        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {
        }
        private void txtBxListTitle_TextChanged(object sender, EventArgs e)
        {
        }
        private void btnBidders_Click_1(object sender, EventArgs e)
        {
        }
        private void btnAddItems_Click(object sender, EventArgs e)
        {
            CSC670TeamProject.AddItems adI = new CSC670TeamProject.AddItems();
            adI.Show();
        }
    }
}
