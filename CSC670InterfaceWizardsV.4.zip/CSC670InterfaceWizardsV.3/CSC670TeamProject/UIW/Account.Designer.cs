﻿namespace CSC670TeamProject
{
    partial class Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Account));
            this.gpbPaymentinfo = new System.Windows.Forms.GroupBox();
            this.dudst = new System.Windows.Forms.DomainUpDown();
            this.tbzip = new System.Windows.Forms.TextBox();
            this.tbcity = new System.Windows.Forms.TextBox();
            this.tbbillingaddress = new System.Windows.Forms.TextBox();
            this.tbccv = new System.Windows.Forms.TextBox();
            this.tbexpirationdate = new System.Windows.Forms.TextBox();
            this.tbcardnumber = new System.Windows.Forms.TextBox();
            this.tbnameoncard = new System.Windows.Forms.TextBox();
            this.cb6 = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.cbuseaccountonfile = new System.Windows.Forms.CheckBox();
            this.cbdebitcreditcard = new System.Windows.Forms.CheckBox();
            this.cbpaypal = new System.Windows.Forms.CheckBox();
            this.cbcheck = new System.Windows.Forms.CheckBox();
            this.cbcash = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.btnnew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.gpbPaymentinfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpbPaymentinfo
            // 
            this.gpbPaymentinfo.Controls.Add(this.dudst);
            this.gpbPaymentinfo.Controls.Add(this.tbzip);
            this.gpbPaymentinfo.Controls.Add(this.tbcity);
            this.gpbPaymentinfo.Controls.Add(this.tbbillingaddress);
            this.gpbPaymentinfo.Controls.Add(this.tbccv);
            this.gpbPaymentinfo.Controls.Add(this.tbexpirationdate);
            this.gpbPaymentinfo.Controls.Add(this.tbcardnumber);
            this.gpbPaymentinfo.Controls.Add(this.tbnameoncard);
            this.gpbPaymentinfo.Controls.Add(this.cb6);
            this.gpbPaymentinfo.Controls.Add(this.label12);
            this.gpbPaymentinfo.Controls.Add(this.label13);
            this.gpbPaymentinfo.Controls.Add(this.label14);
            this.gpbPaymentinfo.Controls.Add(this.label15);
            this.gpbPaymentinfo.Controls.Add(this.label16);
            this.gpbPaymentinfo.Controls.Add(this.label17);
            this.gpbPaymentinfo.Controls.Add(this.label18);
            this.gpbPaymentinfo.Controls.Add(this.label19);
            this.gpbPaymentinfo.Controls.Add(this.label20);
            this.gpbPaymentinfo.Controls.Add(this.cbuseaccountonfile);
            this.gpbPaymentinfo.Controls.Add(this.cbdebitcreditcard);
            this.gpbPaymentinfo.Controls.Add(this.cbpaypal);
            this.gpbPaymentinfo.Controls.Add(this.cbcheck);
            this.gpbPaymentinfo.Controls.Add(this.cbcash);
            this.gpbPaymentinfo.Location = new System.Drawing.Point(341, 32);
            this.gpbPaymentinfo.Name = "gpbPaymentinfo";
            this.gpbPaymentinfo.Size = new System.Drawing.Size(325, 293);
            this.gpbPaymentinfo.TabIndex = 69;
            this.gpbPaymentinfo.TabStop = false;
            this.gpbPaymentinfo.Text = "Payment Info.";
            // 
            // dudst
            // 
            this.dudst.Items.Add("CA");
            this.dudst.Items.Add("NM");
            this.dudst.Items.Add("KS");
            this.dudst.Location = new System.Drawing.Point(183, 260);
            this.dudst.Name = "dudst";
            this.dudst.Size = new System.Drawing.Size(39, 20);
            this.dudst.TabIndex = 22;
            this.dudst.Text = "ST";
            // 
            // tbzip
            // 
            this.tbzip.Location = new System.Drawing.Point(259, 257);
            this.tbzip.Name = "tbzip";
            this.tbzip.Size = new System.Drawing.Size(57, 20);
            this.tbzip.TabIndex = 21;
            this.tbzip.Text = "Text here";
            // 
            // tbcity
            // 
            this.tbcity.Location = new System.Drawing.Point(47, 260);
            this.tbcity.Name = "tbcity";
            this.tbcity.Size = new System.Drawing.Size(106, 20);
            this.tbcity.TabIndex = 20;
            this.tbcity.Text = "Text here";
            // 
            // tbbillingaddress
            // 
            this.tbbillingaddress.Location = new System.Drawing.Point(114, 225);
            this.tbbillingaddress.Name = "tbbillingaddress";
            this.tbbillingaddress.Size = new System.Drawing.Size(202, 20);
            this.tbbillingaddress.TabIndex = 19;
            this.tbbillingaddress.Text = "Text here";
            // 
            // tbccv
            // 
            this.tbccv.Location = new System.Drawing.Point(245, 157);
            this.tbccv.Name = "tbccv";
            this.tbccv.Size = new System.Drawing.Size(71, 20);
            this.tbccv.TabIndex = 18;
            this.tbccv.Text = "Text here";
            // 
            // tbexpirationdate
            // 
            this.tbexpirationdate.Location = new System.Drawing.Point(96, 158);
            this.tbexpirationdate.Name = "tbexpirationdate";
            this.tbexpirationdate.Size = new System.Drawing.Size(89, 20);
            this.tbexpirationdate.TabIndex = 17;
            this.tbexpirationdate.Text = "MM/YY";
            // 
            // tbcardnumber
            // 
            this.tbcardnumber.Location = new System.Drawing.Point(114, 131);
            this.tbcardnumber.Name = "tbcardnumber";
            this.tbcardnumber.Size = new System.Drawing.Size(202, 20);
            this.tbcardnumber.TabIndex = 16;
            this.tbcardnumber.Text = "Text here";
            // 
            // tbnameoncard
            // 
            this.tbnameoncard.Location = new System.Drawing.Point(114, 102);
            this.tbnameoncard.Name = "tbnameoncard";
            this.tbnameoncard.Size = new System.Drawing.Size(202, 20);
            this.tbnameoncard.TabIndex = 15;
            this.tbnameoncard.Text = "Text here";
            // 
            // cb6
            // 
            this.cb6.AutoSize = true;
            this.cb6.Location = new System.Drawing.Point(12, 196);
            this.cb6.Name = "cb6";
            this.cb6.Size = new System.Drawing.Size(15, 14);
            this.cb6.TabIndex = 14;
            this.cb6.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(226, 261);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 16);
            this.label12.TabIndex = 13;
            this.label12.Text = "Zip";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(159, 262);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(20, 16);
            this.label13.TabIndex = 12;
            this.label13.Text = "St";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 261);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 16);
            this.label14.TabIndex = 11;
            this.label14.Text = "City";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(12, 225);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 16);
            this.label15.TabIndex = 10;
            this.label15.Text = "Billing Address";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(50, 194);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(194, 16);
            this.label16.TabIndex = 9;
            this.label16.Text = "Address: Same as Account Info";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(199, 159);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 16);
            this.label17.TabIndex = 8;
            this.label17.Text = "CCV";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(12, 159);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 16);
            this.label18.TabIndex = 7;
            this.label18.Text = "Expiration";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(12, 131);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 16);
            this.label19.TabIndex = 6;
            this.label19.Text = "Card Number";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(12, 103);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(95, 16);
            this.label20.TabIndex = 5;
            this.label20.Text = "Name on Card";
            // 
            // cbuseaccountonfile
            // 
            this.cbuseaccountonfile.AutoSize = true;
            this.cbuseaccountonfile.Location = new System.Drawing.Point(12, 69);
            this.cbuseaccountonfile.Name = "cbuseaccountonfile";
            this.cbuseaccountonfile.Size = new System.Drawing.Size(124, 17);
            this.cbuseaccountonfile.TabIndex = 4;
            this.cbuseaccountonfile.Text = "Use Account On File";
            this.cbuseaccountonfile.UseVisualStyleBackColor = true;
            // 
            // cbdebitcreditcard
            // 
            this.cbdebitcreditcard.AutoSize = true;
            this.cbdebitcreditcard.Location = new System.Drawing.Point(12, 46);
            this.cbdebitcreditcard.Name = "cbdebitcreditcard";
            this.cbdebitcreditcard.Size = new System.Drawing.Size(114, 17);
            this.cbdebitcreditcard.TabIndex = 3;
            this.cbdebitcreditcard.Text = "Debit / Credit Card";
            this.cbdebitcreditcard.UseVisualStyleBackColor = true;
            // 
            // cbpaypal
            // 
            this.cbpaypal.AutoSize = true;
            this.cbpaypal.Location = new System.Drawing.Point(155, 23);
            this.cbpaypal.Name = "cbpaypal";
            this.cbpaypal.Size = new System.Drawing.Size(59, 17);
            this.cbpaypal.TabIndex = 2;
            this.cbpaypal.Text = "PayPal";
            this.cbpaypal.UseVisualStyleBackColor = true;
            // 
            // cbcheck
            // 
            this.cbcheck.AutoSize = true;
            this.cbcheck.Location = new System.Drawing.Point(82, 23);
            this.cbcheck.Name = "cbcheck";
            this.cbcheck.Size = new System.Drawing.Size(57, 17);
            this.cbcheck.TabIndex = 1;
            this.cbcheck.Text = "Check";
            this.cbcheck.UseVisualStyleBackColor = true;
            // 
            // cbcash
            // 
            this.cbcash.AutoSize = true;
            this.cbcash.Location = new System.Drawing.Point(12, 23);
            this.cbcash.Name = "cbcash";
            this.cbcash.Size = new System.Drawing.Size(50, 17);
            this.cbcash.TabIndex = 0;
            this.cbcash.Text = "Cash";
            this.cbcash.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(216, 218);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 13);
            this.label11.TabIndex = 68;
            this.label11.Text = "Zip";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(87, 144);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(237, 20);
            this.textBox8.TabIndex = 67;
            this.textBox8.Text = "AddressLine";
            // 
            // btnnew
            // 
            this.btnnew.BackColor = System.Drawing.Color.LightBlue;
            this.btnnew.Location = new System.Drawing.Point(480, 345);
            this.btnnew.Name = "btnnew";
            this.btnnew.Size = new System.Drawing.Size(75, 34);
            this.btnnew.TabIndex = 66;
            this.btnnew.Text = "New";
            this.btnnew.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.LightBlue;
            this.btnSave.Location = new System.Drawing.Point(591, 345);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 34);
            this.btnSave.TabIndex = 65;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.BackColor = System.Drawing.Color.LightBlue;
            this.BtnDelete.Location = new System.Drawing.Point(31, 345);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(75, 34);
            this.BtnDelete.TabIndex = 64;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.UseVisualStyleBackColor = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(87, 214);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(79, 21);
            this.comboBox1.TabIndex = 63;
            this.comboBox1.Text = "Select State";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(87, 285);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(237, 20);
            this.textBox2.TabIndex = 62;
            this.textBox2.Text = "email address";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(87, 250);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(237, 20);
            this.textBox3.TabIndex = 61;
            this.textBox3.Text = "Phone#";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(253, 215);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(71, 20);
            this.textBox4.TabIndex = 60;
            this.textBox4.Text = "Zip+4";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(87, 74);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(237, 20);
            this.textBox5.TabIndex = 57;
            this.textBox5.Text = "FullName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 56;
            this.label4.Text = "Email";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 55;
            this.label5.Text = "Phone";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 218);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 54;
            this.label6.Text = "State";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(28, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 13);
            this.label7.TabIndex = 53;
            this.label7.Text = "City";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 77);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 51;
            this.label8.Text = "Name";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(87, 179);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(237, 20);
            this.textBox6.TabIndex = 59;
            this.textBox6.Text = "City";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(87, 109);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(237, 20);
            this.textBox7.TabIndex = 58;
            this.textBox7.Text = "AddressLine";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 52;
            this.label9.Text = "Address";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(169, 30);
            this.label10.TabIndex = 50;
            this.label10.Text = "User Information";
            // 
            // Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(699, 391);
            this.Controls.Add(this.gpbPaymentinfo);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.btnnew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Account";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Account";
            this.Load += new System.EventHandler(this.Account_Load);
            this.gpbPaymentinfo.ResumeLayout(false);
            this.gpbPaymentinfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gpbPaymentinfo;
        private System.Windows.Forms.DomainUpDown dudst;
        private System.Windows.Forms.TextBox tbzip;
        private System.Windows.Forms.TextBox tbcity;
        private System.Windows.Forms.TextBox tbbillingaddress;
        private System.Windows.Forms.TextBox tbccv;
        private System.Windows.Forms.TextBox tbexpirationdate;
        private System.Windows.Forms.TextBox tbcardnumber;
        private System.Windows.Forms.TextBox tbnameoncard;
        private System.Windows.Forms.CheckBox cb6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox cbuseaccountonfile;
        private System.Windows.Forms.CheckBox cbdebitcreditcard;
        private System.Windows.Forms.CheckBox cbpaypal;
        private System.Windows.Forms.CheckBox cbcheck;
        private System.Windows.Forms.CheckBox cbcash;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox8;
        internal System.Windows.Forms.Button btnnew;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}