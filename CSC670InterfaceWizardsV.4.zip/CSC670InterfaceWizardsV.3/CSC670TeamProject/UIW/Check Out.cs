﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC670TeamProject
{
    public partial class checkOutPage : Form
    {
        public checkOutPage()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void label2_Click(object sender, EventArgs e)
        {
        }
        private void label1_Click_1(object sender, EventArgs e)
        {
        }
        private void btnAuctionItems_Click(object sender, EventArgs e)
        {
           // AuctionItemsPage aIP = new AuctionItemsPage();
           // aIP.Show();
        }
        private void btnMain_Click(object sender, EventArgs e)
        {
            //EventPage eP = new EventPage();
            //eP.Show();
            this.Hide();
        }
        private void BidderPage_Load(object sender, EventArgs e)
        {     
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            StreamReader myReader = new StreamReader("Thank you.txt");
            string line = "";

            while (line != null)
            {
                line = myReader.ReadLine();
                if (line != null)
                    Console.WriteLine(line);
            }
            myReader.Close();
            Console.ReadLine();
            
        }
        private void label9_Click(object sender, EventArgs e)
        {
        }
        private void textBox7_TextChanged(object sender, EventArgs e)
        {
        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
        }
        private void tbcardnumber_TextChanged(object sender, EventArgs e)
        {
        }
        private void tbccv_TextChanged(object sender, EventArgs e)
        {
        }
        private void cb6_CheckedChanged(object sender, EventArgs e)
        {
        }
        private void tbbillingaddress_TextChanged(object sender, EventArgs e)
        {
        }
        private void tbcity_TextChanged(object sender, EventArgs e)
        {
        }
        private void label12_Click(object sender, EventArgs e)
        {
        }
        private void label17_Click(object sender, EventArgs e)
        {
        }
        private void lblbiddercheckout_Click(object sender, EventArgs e)
        {
        }
        private void txtBxListTitle_TextChanged(object sender, EventArgs e)
        {
        }
        private void btnBidders_Click(object sender, EventArgs e)
        {
        }
    }
}
