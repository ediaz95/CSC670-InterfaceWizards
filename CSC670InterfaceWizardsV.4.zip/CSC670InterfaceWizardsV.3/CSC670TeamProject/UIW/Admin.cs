﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC670TeamProject
{
    public partial class adminPage : Form    
    {
        public adminPage()
        {
            InitializeComponent();
        }
        private void adminPage_Load(object sender, EventArgs e)
        {
            btnAdminInventory.Visible = true;
            btnRefresh.Visible = true;
            btnEditSelected.Visible = true;
            btnRefresh.Visible = true;
        }
        private void label1_Click(object sender, EventArgs e)
        {
          mainPage mp   = new mainPage();
            mp.Show();
            this.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            ListViewItem lvi = new ListViewItem("LName, FName");
            lvi.SubItems.Add("John Doe");
            lvi.SubItems.Add("JohnDoe@mail.com");
            lvi.SubItems.Add("sam123");
            lvi.SubItems.Add("Full");
            listView1.Items.Add(lvi);
        }
        private void btnAdminInventory_Click(object sender, EventArgs e)
        {
            adminInventoryPage adminInventory = new adminInventoryPage();
            adminInventory.Show();
            this.Close();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void label2_Click(object sender, EventArgs e)
        {
        }
        private void label1_Click_1(object sender, EventArgs e)
        {
        }
        private void label1_Click_2(object sender, EventArgs e)
        {
        }     
       
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }
        private void toolStripContainer1_ContentPanel_Load(object sender, EventArgs e)
        {
        }
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }
        private void tabAccountReports_Click(object sender, EventArgs e)
        {            
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {            
        }       
        private void listView_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {            
        } 
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {           
        }

       
    }
}
