﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC670TeamProject
{
    public partial class ResetRequest : Form
    {
        public ResetRequest()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            CSC670TeamProject.Login Login = new CSC670TeamProject.Login();            
        }
        private void ResetRequest_Load(object sender, EventArgs e)
        {
        }
    }
}
