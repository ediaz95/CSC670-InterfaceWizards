﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC670TeamProject
{
    public partial class Account : Form
    {
        public Account()
        {
            InitializeComponent();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        private void tbcity_TextChanged(object sender, EventArgs e)
        {
        }
        private void tbbillingaddress_TextChanged(object sender, EventArgs e)
        {
        }
        private void tbccv_TextChanged(object sender, EventArgs e)
        {
        }
        private void tbcardnumber_TextChanged(object sender, EventArgs e)
        {
        }
        private void cb6_CheckedChanged(object sender, EventArgs e)
        {
        }
        private void label12_Click(object sender, EventArgs e)
        {
        }
        private void label17_Click(object sender, EventArgs e)
        {
        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
        }
        private void textBox7_TextChanged(object sender, EventArgs e)
        {
        }
        private void label9_Click(object sender, EventArgs e)
        {
        }

        private void Account_Load(object sender, EventArgs e)
        {

        }   
    }
}
