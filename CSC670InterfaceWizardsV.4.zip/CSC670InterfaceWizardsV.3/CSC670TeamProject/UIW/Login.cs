﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSC670TeamProject
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (userNameTextBox.Text == "admin" && passwordTextBox.Text == "admin")
            {
                this.Hide();
                adminPage ap = new adminPage();
                ap.Show();
            }
            else if (userNameTextBox.Text == "a" && passwordTextBox.Text == "1")
            {
                this.Hide();
                myFormControl fc = new myFormControl();
            }
            else
            {
                MessageBox mb = new MessageBox();
                mb.Show();
            } 
        }          
        private void linklblCreate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {            
            CSC670TeamProject.Create_Account openForm = new CSC670TeamProject.Create_Account();
            openForm.Show();
        }
        private void linklblDemo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {           
            CSC670TeamProject.ResetRequest openForm = new CSC670TeamProject.ResetRequest();
            openForm.Show();
        }
        private void passwordTextBox_TextChanged(object sender, EventArgs e)
        {
           string  password =  passwordTextBox.Text;         
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }       
        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void pBoxAppLogo_Click(object sender, EventArgs e)
        {
        }
        private void userNameTextBox_TextChanged(object sender, EventArgs e)
        {
        }
        private void Login_Load(object sender, EventArgs e)
        {
        }                       
        
    }
}
