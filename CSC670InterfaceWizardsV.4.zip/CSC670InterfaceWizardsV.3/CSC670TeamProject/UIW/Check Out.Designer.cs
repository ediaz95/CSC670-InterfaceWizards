﻿namespace CSC670TeamProject
{
    partial class checkOutPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(checkOutPage));
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.tabControlBidders = new System.Windows.Forms.TabControl();
            this.tabView = new System.Windows.Forms.TabPage();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblBidderinformation = new System.Windows.Forms.Label();
            this.tabAddEdit = new System.Windows.Forms.TabPage();
            this.gpbPaymentinfo = new System.Windows.Forms.GroupBox();
            this.dudst = new System.Windows.Forms.DomainUpDown();
            this.tbzip = new System.Windows.Forms.TextBox();
            this.tbcity = new System.Windows.Forms.TextBox();
            this.tbbillingaddress = new System.Windows.Forms.TextBox();
            this.tbccv = new System.Windows.Forms.TextBox();
            this.tbexpirationdate = new System.Windows.Forms.TextBox();
            this.tbcardnumber = new System.Windows.Forms.TextBox();
            this.tbnameoncard = new System.Windows.Forms.TextBox();
            this.cb6 = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.cbuseaccountonfile = new System.Windows.Forms.CheckBox();
            this.cbdebitcreditcard = new System.Windows.Forms.CheckBox();
            this.cbpaypal = new System.Windows.Forms.CheckBox();
            this.cbcheck = new System.Windows.Forms.CheckBox();
            this.cbcash = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.btnnew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabEditAddress = new System.Windows.Forms.TabPage();
            this.btnSaveUser = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnDelete1 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.cbSelectstate = new System.Windows.Forms.ComboBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblBiddersPage = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnApply = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.printToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControlBidders.SuspendLayout();
            this.tabView.SuspendLayout();
            this.tabAddEdit.SuspendLayout();
            this.gpbPaymentinfo.SuspendLayout();
            this.tabEditAddress.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Font = new System.Drawing.Font("Georgia", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyName.Location = new System.Drawing.Point(305, 31);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(277, 34);
            this.lblCompanyName.TabIndex = 1;
            this.lblCompanyName.Text = "Property Systems";
            this.lblCompanyName.Click += new System.EventHandler(this.label2_Click);
            // 
            // tabControlBidders
            // 
            this.tabControlBidders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControlBidders.Controls.Add(this.tabView);
            this.tabControlBidders.Controls.Add(this.tabAddEdit);
            this.tabControlBidders.Controls.Add(this.tabEditAddress);
            this.tabControlBidders.Location = new System.Drawing.Point(24, 79);
            this.tabControlBidders.Name = "tabControlBidders";
            this.tabControlBidders.SelectedIndex = 0;
            this.tabControlBidders.Size = new System.Drawing.Size(676, 487);
            this.tabControlBidders.TabIndex = 6;
            // 
            // tabView
            // 
            this.tabView.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabView.Controls.Add(this.textBox15);
            this.tabView.Controls.Add(this.label30);
            this.tabView.Controls.Add(this.label29);
            this.tabView.Controls.Add(this.label28);
            this.tabView.Controls.Add(this.label1);
            this.tabView.Controls.Add(this.radioButton3);
            this.tabView.Controls.Add(this.radioButton2);
            this.tabView.Controls.Add(this.radioButton1);
            this.tabView.Controls.Add(this.listView2);
            this.tabView.Controls.Add(this.listView1);
            this.tabView.Controls.Add(this.lblBidderinformation);
            this.tabView.Location = new System.Drawing.Point(4, 22);
            this.tabView.Name = "tabView";
            this.tabView.Padding = new System.Windows.Forms.Padding(3);
            this.tabView.Size = new System.Drawing.Size(668, 461);
            this.tabView.TabIndex = 0;
            this.tabView.Text = "Profile Settings";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(569, 428);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(87, 20);
            this.textBox15.TabIndex = 27;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(506, 383);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(48, 13);
            this.label30.TabIndex = 26;
            this.label30.Text = "Shipping";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(523, 405);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(25, 13);
            this.label29.TabIndex = 25;
            this.label29.Text = "Tax";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(523, 428);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(31, 13);
            this.label28.TabIndex = 24;
            this.label28.Text = "Total";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(481, 358);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "Promtion/Coupon";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(299, 356);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(63, 17);
            this.radioButton3.TabIndex = 21;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Pick Up";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(36, 392);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(110, 17);
            this.radioButton2.TabIndex = 20;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Expedite Shipping";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(36, 356);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(112, 17);
            this.radioButton1.TabIndex = 19;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Standard Shipping";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6});
            this.listView2.Location = new System.Drawing.Point(6, 322);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(653, 129);
            this.listView2.TabIndex = 18;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "";
            this.columnHeader6.Width = 0;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(6, 56);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(650, 265);
            this.listView1.TabIndex = 17;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Item#";
            this.columnHeader1.Width = 141;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Description";
            this.columnHeader2.Width = 205;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Quantity";
            this.columnHeader3.Width = 65;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Status";
            this.columnHeader4.Width = 156;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Price";
            this.columnHeader5.Width = 440;
            // 
            // lblBidderinformation
            // 
            this.lblBidderinformation.AutoSize = true;
            this.lblBidderinformation.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBidderinformation.Location = new System.Drawing.Point(6, 7);
            this.lblBidderinformation.Name = "lblBidderinformation";
            this.lblBidderinformation.Size = new System.Drawing.Size(79, 30);
            this.lblBidderinformation.TabIndex = 16;
            this.lblBidderinformation.Text = "Invoice";
            // 
            // tabAddEdit
            // 
            this.tabAddEdit.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabAddEdit.Controls.Add(this.gpbPaymentinfo);
            this.tabAddEdit.Controls.Add(this.label11);
            this.tabAddEdit.Controls.Add(this.textBox8);
            this.tabAddEdit.Controls.Add(this.btnnew);
            this.tabAddEdit.Controls.Add(this.btnSave);
            this.tabAddEdit.Controls.Add(this.BtnDelete);
            this.tabAddEdit.Controls.Add(this.comboBox1);
            this.tabAddEdit.Controls.Add(this.textBox2);
            this.tabAddEdit.Controls.Add(this.textBox3);
            this.tabAddEdit.Controls.Add(this.textBox4);
            this.tabAddEdit.Controls.Add(this.textBox5);
            this.tabAddEdit.Controls.Add(this.label4);
            this.tabAddEdit.Controls.Add(this.label5);
            this.tabAddEdit.Controls.Add(this.label6);
            this.tabAddEdit.Controls.Add(this.label7);
            this.tabAddEdit.Controls.Add(this.label8);
            this.tabAddEdit.Controls.Add(this.textBox6);
            this.tabAddEdit.Controls.Add(this.textBox7);
            this.tabAddEdit.Controls.Add(this.label9);
            this.tabAddEdit.Controls.Add(this.label10);
            this.tabAddEdit.Location = new System.Drawing.Point(4, 22);
            this.tabAddEdit.Name = "tabAddEdit";
            this.tabAddEdit.Padding = new System.Windows.Forms.Padding(3);
            this.tabAddEdit.Size = new System.Drawing.Size(668, 461);
            this.tabAddEdit.TabIndex = 1;
            this.tabAddEdit.Text = "User Information";
            // 
            // gpbPaymentinfo
            // 
            this.gpbPaymentinfo.Controls.Add(this.dudst);
            this.gpbPaymentinfo.Controls.Add(this.tbzip);
            this.gpbPaymentinfo.Controls.Add(this.tbcity);
            this.gpbPaymentinfo.Controls.Add(this.tbbillingaddress);
            this.gpbPaymentinfo.Controls.Add(this.tbccv);
            this.gpbPaymentinfo.Controls.Add(this.tbexpirationdate);
            this.gpbPaymentinfo.Controls.Add(this.tbcardnumber);
            this.gpbPaymentinfo.Controls.Add(this.tbnameoncard);
            this.gpbPaymentinfo.Controls.Add(this.cb6);
            this.gpbPaymentinfo.Controls.Add(this.label12);
            this.gpbPaymentinfo.Controls.Add(this.label13);
            this.gpbPaymentinfo.Controls.Add(this.label14);
            this.gpbPaymentinfo.Controls.Add(this.label15);
            this.gpbPaymentinfo.Controls.Add(this.label16);
            this.gpbPaymentinfo.Controls.Add(this.label17);
            this.gpbPaymentinfo.Controls.Add(this.label18);
            this.gpbPaymentinfo.Controls.Add(this.label19);
            this.gpbPaymentinfo.Controls.Add(this.label20);
            this.gpbPaymentinfo.Controls.Add(this.cbuseaccountonfile);
            this.gpbPaymentinfo.Controls.Add(this.cbdebitcreditcard);
            this.gpbPaymentinfo.Controls.Add(this.cbpaypal);
            this.gpbPaymentinfo.Controls.Add(this.cbcheck);
            this.gpbPaymentinfo.Controls.Add(this.cbcash);
            this.gpbPaymentinfo.Location = new System.Drawing.Point(340, 9);
            this.gpbPaymentinfo.Name = "gpbPaymentinfo";
            this.gpbPaymentinfo.Size = new System.Drawing.Size(325, 293);
            this.gpbPaymentinfo.TabIndex = 49;
            this.gpbPaymentinfo.TabStop = false;
            this.gpbPaymentinfo.Text = "Payment Info.";
            // 
            // dudst
            // 
            this.dudst.Items.Add("CA");
            this.dudst.Items.Add("NM");
            this.dudst.Items.Add("KS");
            this.dudst.Location = new System.Drawing.Point(183, 260);
            this.dudst.Name = "dudst";
            this.dudst.Size = new System.Drawing.Size(39, 20);
            this.dudst.TabIndex = 22;
            this.dudst.Text = "ST";
            // 
            // tbzip
            // 
            this.tbzip.Location = new System.Drawing.Point(259, 257);
            this.tbzip.Name = "tbzip";
            this.tbzip.Size = new System.Drawing.Size(57, 20);
            this.tbzip.TabIndex = 21;
            this.tbzip.Text = "Text here";
            // 
            // tbcity
            // 
            this.tbcity.Location = new System.Drawing.Point(47, 260);
            this.tbcity.Name = "tbcity";
            this.tbcity.Size = new System.Drawing.Size(106, 20);
            this.tbcity.TabIndex = 20;
            this.tbcity.Text = "Text here";
            this.tbcity.TextChanged += new System.EventHandler(this.tbcity_TextChanged);
            // 
            // tbbillingaddress
            // 
            this.tbbillingaddress.Location = new System.Drawing.Point(114, 225);
            this.tbbillingaddress.Name = "tbbillingaddress";
            this.tbbillingaddress.Size = new System.Drawing.Size(202, 20);
            this.tbbillingaddress.TabIndex = 19;
            this.tbbillingaddress.Text = "Text here";
            this.tbbillingaddress.TextChanged += new System.EventHandler(this.tbbillingaddress_TextChanged);
            // 
            // tbccv
            // 
            this.tbccv.Location = new System.Drawing.Point(245, 157);
            this.tbccv.Name = "tbccv";
            this.tbccv.Size = new System.Drawing.Size(71, 20);
            this.tbccv.TabIndex = 18;
            this.tbccv.Text = "Text here";
            this.tbccv.TextChanged += new System.EventHandler(this.tbccv_TextChanged);
            // 
            // tbexpirationdate
            // 
            this.tbexpirationdate.Location = new System.Drawing.Point(96, 158);
            this.tbexpirationdate.Name = "tbexpirationdate";
            this.tbexpirationdate.Size = new System.Drawing.Size(89, 20);
            this.tbexpirationdate.TabIndex = 17;
            this.tbexpirationdate.Text = "MM/YY";
            // 
            // tbcardnumber
            // 
            this.tbcardnumber.Location = new System.Drawing.Point(114, 131);
            this.tbcardnumber.Name = "tbcardnumber";
            this.tbcardnumber.Size = new System.Drawing.Size(202, 20);
            this.tbcardnumber.TabIndex = 16;
            this.tbcardnumber.Text = "Text here";
            this.tbcardnumber.TextChanged += new System.EventHandler(this.tbcardnumber_TextChanged);
            // 
            // tbnameoncard
            // 
            this.tbnameoncard.Location = new System.Drawing.Point(114, 102);
            this.tbnameoncard.Name = "tbnameoncard";
            this.tbnameoncard.Size = new System.Drawing.Size(202, 20);
            this.tbnameoncard.TabIndex = 15;
            this.tbnameoncard.Text = "Text here";
            // 
            // cb6
            // 
            this.cb6.AutoSize = true;
            this.cb6.Location = new System.Drawing.Point(12, 196);
            this.cb6.Name = "cb6";
            this.cb6.Size = new System.Drawing.Size(15, 14);
            this.cb6.TabIndex = 14;
            this.cb6.UseVisualStyleBackColor = true;
            this.cb6.CheckedChanged += new System.EventHandler(this.cb6_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(226, 261);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 16);
            this.label12.TabIndex = 13;
            this.label12.Text = "Zip";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(159, 262);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(20, 16);
            this.label13.TabIndex = 12;
            this.label13.Text = "St";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 261);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 16);
            this.label14.TabIndex = 11;
            this.label14.Text = "City";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(12, 225);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 16);
            this.label15.TabIndex = 10;
            this.label15.Text = "Billing Address";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(50, 194);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(194, 16);
            this.label16.TabIndex = 9;
            this.label16.Text = "Address: Same as Account Info";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(199, 159);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 16);
            this.label17.TabIndex = 8;
            this.label17.Text = "CCV";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(12, 159);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 16);
            this.label18.TabIndex = 7;
            this.label18.Text = "Expiration";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(12, 131);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(88, 16);
            this.label19.TabIndex = 6;
            this.label19.Text = "Card Number";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(12, 103);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(95, 16);
            this.label20.TabIndex = 5;
            this.label20.Text = "Name on Card";
            // 
            // cbuseaccountonfile
            // 
            this.cbuseaccountonfile.AutoSize = true;
            this.cbuseaccountonfile.Location = new System.Drawing.Point(12, 69);
            this.cbuseaccountonfile.Name = "cbuseaccountonfile";
            this.cbuseaccountonfile.Size = new System.Drawing.Size(124, 17);
            this.cbuseaccountonfile.TabIndex = 4;
            this.cbuseaccountonfile.Text = "Use Account On File";
            this.cbuseaccountonfile.UseVisualStyleBackColor = true;
            // 
            // cbdebitcreditcard
            // 
            this.cbdebitcreditcard.AutoSize = true;
            this.cbdebitcreditcard.Location = new System.Drawing.Point(12, 46);
            this.cbdebitcreditcard.Name = "cbdebitcreditcard";
            this.cbdebitcreditcard.Size = new System.Drawing.Size(114, 17);
            this.cbdebitcreditcard.TabIndex = 3;
            this.cbdebitcreditcard.Text = "Debit / Credit Card";
            this.cbdebitcreditcard.UseVisualStyleBackColor = true;
            // 
            // cbpaypal
            // 
            this.cbpaypal.AutoSize = true;
            this.cbpaypal.Location = new System.Drawing.Point(155, 23);
            this.cbpaypal.Name = "cbpaypal";
            this.cbpaypal.Size = new System.Drawing.Size(59, 17);
            this.cbpaypal.TabIndex = 2;
            this.cbpaypal.Text = "PayPal";
            this.cbpaypal.UseVisualStyleBackColor = true;
            // 
            // cbcheck
            // 
            this.cbcheck.AutoSize = true;
            this.cbcheck.Location = new System.Drawing.Point(82, 23);
            this.cbcheck.Name = "cbcheck";
            this.cbcheck.Size = new System.Drawing.Size(57, 17);
            this.cbcheck.TabIndex = 1;
            this.cbcheck.Text = "Check";
            this.cbcheck.UseVisualStyleBackColor = true;
            // 
            // cbcash
            // 
            this.cbcash.AutoSize = true;
            this.cbcash.Location = new System.Drawing.Point(12, 23);
            this.cbcash.Name = "cbcash";
            this.cbcash.Size = new System.Drawing.Size(50, 17);
            this.cbcash.TabIndex = 0;
            this.cbcash.Text = "Cash";
            this.cbcash.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(215, 195);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 13);
            this.label11.TabIndex = 48;
            this.label11.Text = "Zip";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(86, 121);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(237, 20);
            this.textBox8.TabIndex = 47;
            this.textBox8.Text = "AddressLine";
            // 
            // btnnew
            // 
            this.btnnew.Location = new System.Drawing.Point(481, 308);
            this.btnnew.Name = "btnnew";
            this.btnnew.Size = new System.Drawing.Size(75, 23);
            this.btnnew.TabIndex = 46;
            this.btnnew.Text = "New";
            this.btnnew.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(581, 308);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 45;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(25, 308);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(75, 23);
            this.BtnDelete.TabIndex = 44;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(86, 191);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(79, 21);
            this.comboBox1.TabIndex = 43;
            this.comboBox1.Text = "Select State";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(86, 262);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(237, 20);
            this.textBox2.TabIndex = 42;
            this.textBox2.Text = "email address";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(86, 227);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(237, 20);
            this.textBox3.TabIndex = 41;
            this.textBox3.Text = "Phone#";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(252, 192);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(71, 20);
            this.textBox4.TabIndex = 40;
            this.textBox4.Text = "Zip+4";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(86, 51);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(237, 20);
            this.textBox5.TabIndex = 37;
            this.textBox5.Text = "FullName";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 36;
            this.label4.Text = "Email";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 35;
            this.label5.Text = "Phone";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 195);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 34;
            this.label6.Text = "State";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 13);
            this.label7.TabIndex = 33;
            this.label7.Text = "City";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 31;
            this.label8.Text = "Name";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(86, 156);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(237, 20);
            this.textBox6.TabIndex = 39;
            this.textBox6.Text = "City";
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(86, 86);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(237, 20);
            this.textBox7.TabIndex = 38;
            this.textBox7.Text = "AddressLine";
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 32;
            this.label9.Text = "Address";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(11, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(169, 30);
            this.label10.TabIndex = 30;
            this.label10.Text = "User Information";
            // 
            // tabEditAddress
            // 
            this.tabEditAddress.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabEditAddress.Controls.Add(this.btnSaveUser);
            this.tabEditAddress.Controls.Add(this.label2);
            this.tabEditAddress.Controls.Add(this.textBox1);
            this.tabEditAddress.Controls.Add(this.btnDelete1);
            this.tabEditAddress.Controls.Add(this.comboBox2);
            this.tabEditAddress.Controls.Add(this.textBox9);
            this.tabEditAddress.Controls.Add(this.textBox10);
            this.tabEditAddress.Controls.Add(this.textBox11);
            this.tabEditAddress.Controls.Add(this.textBox12);
            this.tabEditAddress.Controls.Add(this.label3);
            this.tabEditAddress.Controls.Add(this.label21);
            this.tabEditAddress.Controls.Add(this.label22);
            this.tabEditAddress.Controls.Add(this.label23);
            this.tabEditAddress.Controls.Add(this.label24);
            this.tabEditAddress.Controls.Add(this.textBox13);
            this.tabEditAddress.Controls.Add(this.textBox14);
            this.tabEditAddress.Controls.Add(this.label25);
            this.tabEditAddress.Controls.Add(this.label26);
            this.tabEditAddress.Location = new System.Drawing.Point(4, 22);
            this.tabEditAddress.Name = "tabEditAddress";
            this.tabEditAddress.Size = new System.Drawing.Size(668, 461);
            this.tabEditAddress.TabIndex = 2;
            this.tabEditAddress.Text = " Edit Address";
            // 
            // btnSaveUser
            // 
            this.btnSaveUser.Location = new System.Drawing.Point(429, 311);
            this.btnSaveUser.Name = "btnSaveUser";
            this.btnSaveUser.Size = new System.Drawing.Size(75, 23);
            this.btnSaveUser.TabIndex = 66;
            this.btnSaveUser.Text = "Save";
            this.btnSaveUser.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(228, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 13);
            this.label2.TabIndex = 65;
            this.label2.Text = "Zip";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(99, 124);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(237, 20);
            this.textBox1.TabIndex = 64;
            this.textBox1.Text = "AddressLine";
            // 
            // btnDelete1
            // 
            this.btnDelete1.Location = new System.Drawing.Point(38, 311);
            this.btnDelete1.Name = "btnDelete1";
            this.btnDelete1.Size = new System.Drawing.Size(75, 23);
            this.btnDelete1.TabIndex = 63;
            this.btnDelete1.Text = "Delete";
            this.btnDelete1.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(99, 194);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(79, 21);
            this.comboBox2.TabIndex = 62;
            this.comboBox2.Text = "Select State";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(99, 265);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(237, 20);
            this.textBox9.TabIndex = 61;
            this.textBox9.Text = "email address";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(99, 230);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(237, 20);
            this.textBox10.TabIndex = 60;
            this.textBox10.Text = "Phone#";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(265, 195);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(71, 20);
            this.textBox11.TabIndex = 59;
            this.textBox11.Text = "Zip+4";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(99, 54);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(237, 20);
            this.textBox12.TabIndex = 56;
            this.textBox12.Text = "FullName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 55;
            this.label3.Text = "Email";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(40, 233);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 13);
            this.label21.TabIndex = 54;
            this.label21.Text = "Phone";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(40, 198);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(32, 13);
            this.label22.TabIndex = 53;
            this.label22.Text = "State";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(40, 162);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(24, 13);
            this.label23.TabIndex = 52;
            this.label23.Text = "City";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(40, 57);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(35, 13);
            this.label24.TabIndex = 50;
            this.label24.Text = "Name";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(99, 159);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(237, 20);
            this.textBox13.TabIndex = 58;
            this.textBox13.Text = "City";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(99, 89);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(237, 20);
            this.textBox14.TabIndex = 57;
            this.textBox14.Text = "AddressLine";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(40, 92);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(45, 13);
            this.label25.TabIndex = 51;
            this.label25.Text = "Address";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(24, 14);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(169, 30);
            this.label26.TabIndex = 49;
            this.label26.Text = "User Information";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(1210, 787);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(54, 23);
            this.button7.TabIndex = 55;
            this.button7.Text = "|< First";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // cbSelectstate
            // 
            this.cbSelectstate.FormattingEnabled = true;
            this.cbSelectstate.Location = new System.Drawing.Point(723, 101);
            this.cbSelectstate.Name = "cbSelectstate";
            this.cbSelectstate.Size = new System.Drawing.Size(113, 21);
            this.cbSelectstate.TabIndex = 29;
            this.cbSelectstate.Text = "Select Address";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.BackColor = System.Drawing.Color.LightBlue;
            this.btnSubmit.Location = new System.Drawing.Point(744, 595);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 36);
            this.btnSubmit.TabIndex = 9;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblBiddersPage
            // 
            this.lblBiddersPage.AutoSize = true;
            this.lblBiddersPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBiddersPage.Location = new System.Drawing.Point(23, 56);
            this.lblBiddersPage.Name = "lblBiddersPage";
            this.lblBiddersPage.Size = new System.Drawing.Size(83, 20);
            this.lblBiddersPage.TabIndex = 10;
            this.lblBiddersPage.Text = "Summary";
            this.lblBiddersPage.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(723, 173);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(113, 21);
            this.comboBox3.TabIndex = 58;
            this.comboBox3.Text = "Choose Payment";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(24, 604);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(223, 20);
            this.textBox16.TabIndex = 59;
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.BackColor = System.Drawing.Color.LightBlue;
            this.btnNext.Location = new System.Drawing.Point(639, 595);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 36);
            this.btnNext.TabIndex = 60;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            // 
            // btnPrevious
            // 
            this.btnPrevious.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrevious.BackColor = System.Drawing.Color.LightBlue;
            this.btnPrevious.Location = new System.Drawing.Point(524, 595);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(75, 36);
            this.btnPrevious.TabIndex = 61;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = false;
            // 
            // btnApply
            // 
            this.btnApply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnApply.BackColor = System.Drawing.Color.LightBlue;
            this.btnApply.Location = new System.Drawing.Point(255, 596);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(75, 35);
            this.btnApply.TabIndex = 62;
            this.btnApply.Text = "Apply";
            this.btnApply.UseVisualStyleBackColor = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(23, 569);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(307, 20);
            this.label31.TabIndex = 63;
            this.label31.Text = "Enter Promtional Code or Coupon Number";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1,
            this.editToolStripMenuItem,
            this.toolsToolStripMenuItem1,
            this.helpToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(848, 24);
            this.menuStrip1.TabIndex = 64;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.BackColor = System.Drawing.Color.LightBlue;
            this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator,
            this.toolStripSeparator1,
            this.printToolStripMenuItem1,
            this.printPreviewToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem1.Text = "File";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(140, 6);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(140, 6);
            // 
            // printToolStripMenuItem1
            // 
            this.printToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripMenuItem1.Image")));
            this.printToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripMenuItem1.Name = "printToolStripMenuItem1";
            this.printToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.printToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.printToolStripMenuItem1.Text = "&Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewToolStripMenuItem.Image")));
            this.printPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.printPreviewToolStripMenuItem.Text = "Print Pre&view";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(140, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator3,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.toolStripSeparator4,
            this.selectAllToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "&Edit";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(141, 6);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripMenuItem.Image")));
            this.cutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.cutToolStripMenuItem.Text = "Cu&t";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripMenuItem.Image")));
            this.copyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.copyToolStripMenuItem.Text = "&Copy";
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripMenuItem.Image")));
            this.pasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.pasteToolStripMenuItem.Text = "&Paste";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(141, 6);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.selectAllToolStripMenuItem.Text = "Select &All";
            // 
            // toolsToolStripMenuItem1
            // 
            this.toolsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.changePasswordToolStripMenuItem});
            this.toolsToolStripMenuItem1.Name = "toolsToolStripMenuItem1";
            this.toolsToolStripMenuItem1.Size = new System.Drawing.Size(48, 20);
            this.toolsToolStripMenuItem1.Text = "&Tools";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accountToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.optionsToolStripMenuItem.Text = "&Options";
            // 
            // accountToolStripMenuItem
            // 
            this.accountToolStripMenuItem.Name = "accountToolStripMenuItem";
            this.accountToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.accountToolStripMenuItem.Text = "Account";
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator5,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem1.Text = "&Help";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(113, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.aboutToolStripMenuItem.Text = "&About...";
            // 
            // checkOutPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(848, 649);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.lblBiddersPage);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.cbSelectstate);
            this.Controls.Add(this.tabControlBidders);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblCompanyName);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 500);
            this.Name = "checkOutPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Check Out Page";
            this.Load += new System.EventHandler(this.BidderPage_Load);
            this.tabControlBidders.ResumeLayout(false);
            this.tabView.ResumeLayout(false);
            this.tabView.PerformLayout();
            this.tabAddEdit.ResumeLayout(false);
            this.tabAddEdit.PerformLayout();
            this.gpbPaymentinfo.ResumeLayout(false);
            this.gpbPaymentinfo.PerformLayout();
            this.tabEditAddress.ResumeLayout(false);
            this.tabEditAddress.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.TabControl tabControlBidders;
        private System.Windows.Forms.TabPage tabAddEdit;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.TabPage tabEditAddress;
        private System.Windows.Forms.ComboBox cbSelectstate;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        internal System.Windows.Forms.Button btnnew;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.GroupBox gpbPaymentinfo;
        private System.Windows.Forms.DomainUpDown dudst;
        private System.Windows.Forms.TextBox tbzip;
        private System.Windows.Forms.TextBox tbcity;
        private System.Windows.Forms.TextBox tbbillingaddress;
        private System.Windows.Forms.TextBox tbccv;
        private System.Windows.Forms.TextBox tbexpirationdate;
        private System.Windows.Forms.TextBox tbcardnumber;
        private System.Windows.Forms.TextBox tbnameoncard;
        private System.Windows.Forms.CheckBox cb6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox cbuseaccountonfile;
        private System.Windows.Forms.CheckBox cbdebitcreditcard;
        private System.Windows.Forms.CheckBox cbpaypal;
        private System.Windows.Forms.CheckBox cbcheck;
        private System.Windows.Forms.CheckBox cbcash;
        internal System.Windows.Forms.Button btnSaveUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        internal System.Windows.Forms.Button btnDelete1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lblBiddersPage;
        private System.Windows.Forms.TabPage tabView;
        private System.Windows.Forms.Label lblBidderinformation;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
    }
}

