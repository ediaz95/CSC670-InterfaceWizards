﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CSC670TeamProject 
{
    public partial class mainPage : Form
    {
        public checkOutPage bP = new checkOutPage();
        public adminInventoryPage aP = new adminInventoryPage();
        public adminPage aIP = new adminPage();              
        
        public mainPage()
        {
            InitializeComponent();             
        }      
      
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void EventPage_Load(object sender, EventArgs e)
        {
            string cb1 = txtBx1.Text = "10.00";
            string cb2 = txtBx2.Text ="$5.00";
            string cb3 = txtBx3.Text = "$300.00";
            string cb4 = txtBx4.Text = "$1.00";
            string cb5 = txtBx5.Text = "$50.00";
            string cb6 = txtBx6.Text = "$25.00";                      
        }            
        
        private void lblCompanyName_Click(object sender, EventArgs e)
        {        
        }
        private void label33_Click(object sender, EventArgs e)
        {        
        }
        private void txtBxListTitle_TextChanged(object sender, EventArgs e)
        {        
        }
       
        private void textBox5_TextChanged_1(object sender, EventArgs e)
        {
        }
        private void groupBox3_Enter(object sender, EventArgs e)
        {
        }                         
        private void label9_Click(object sender, EventArgs e)
        {
        }       
      
        private void pictureBox11_Click(object sender, EventArgs e)
        {
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }
        
        private void txtBx1_TextChanged(object sender, EventArgs e)
        {
        }
        private void txtBx2_TextChanged(object sender, EventArgs e)
        {
        }
        private void txtBx3_TextChanged(object sender, EventArgs e)
        {
        }     
      
        private void txtBx4_TextChanged(object sender, EventArgs e)
        {
        }
        private void txtBx5_TextChanged(object sender, EventArgs e)
        {
        }     
        
        private void btnAcct_Click(object sender, EventArgs e)
        {
            Account mb = new Account();
            mb.Show();
        }            

        private void btnBid1_Click(object sender, EventArgs e)
        {
           // txtBx1.Text += cb1 + Environment.NewLine;
         //   total += cb1;
          //  txtBx1.Text = total.ToString();         
        }

        private void btnBid2_Click(object sender, EventArgs e)
        {
          //  txtBx1.Text += cb1 + Environment.NewLine;
          //  total += cb1;
          //  txtBx1.Text = total.ToString();         
        }

        private void btnBid3_Click(object sender, EventArgs e)
        {
            //txtBx1.Text += cb1 + Environment.NewLine;
          //  total += cb1;
         //   txtBx1.Text = total.ToString();         
       }

        private void btnBid4_Click(object sender, EventArgs e)
      {
           // txtBx1.Text += cb1 + Environment.NewLine;
           // total += cb1;
           // txtBx1.Text = total.ToString();         
        }

        private void btnBid5_Click(object sender, EventArgs e)
        {
           // txtBx1.Text += cb1 + Environment.NewLine;
          //  total += cb1;
           // txtBx1.Text = total.ToString();         
       }

       
        private void btnBid6_Click(object sender, EventArgs e)
        {           
        }
        private void btnFeaturedItems_Click(object sender, EventArgs e)
        {
            FeaturedItems fi = new FeaturedItems();
            fi.Show();
        }
        private void btnElectronics_Click(object sender, EventArgs e)
        {
            Electronics ec = new Electronics();
            ec.Show();
        }
        private void btnCatogories_Click(object sender, EventArgs e)
        {

        }

        private void btnBN1_Click(object sender, EventArgs e)
        {
            this.Hide();
            checkOutPage cko = new checkOutPage();
            cko.Show();
        }

        private void btnBN2_Click(object sender, EventArgs e)
        {
            this.Hide();
            checkOutPage cko = new checkOutPage();
            cko.Show();            
        }

        private void btnBN3_Click(object sender, EventArgs e)
        {
            this.Hide();
            checkOutPage cko = new checkOutPage();
            cko.Show();
        }

        private void btnBN4_Click(object sender, EventArgs e)
        {
            this.Hide();
            checkOutPage cko = new checkOutPage();
            cko.Show();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Reset_Password rp = new Reset_Password();
            rp.Show();
        }

        private void accountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Account act = new Account();
            act.Show();
        }
        private void btnMagnifer_Click(object sender, EventArgs e)
        {
            Magnifier20070401.MagnifierMainForm aa = new Magnifier20070401.MagnifierMainForm();

            aa.Show();
        }
        private void lblSoftwareTitle_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminPage ap = new adminPage();
            ap.Show();
        }    
      
     }
}
